# EduPlayer

EduPlayer is a video sharing platform where users can:

- Watch videos
- Upload their own content
- Comment on videos
- Navigate between videos seamlessly

Built using **Next.js**, **TypeScript**, **Tailwind CSS**, and **React Query**.

---

## Live Demo

_This project is intended to be run locally._

---

## Features

- Upload video with title, URL, and description
- Leave comments on videos
- Navigate between videos using “Previous” and “Next”
- Shows relative time since video was uploaded
- Simple and clean UI with responsive layout
- Optimized with React Query caching

---

## Getting Started

### Prerequisites

- Node.js (18+)
- npm or yarn

### Install & Run

```bash
# Clone the repo
git clone https://github.com/yourusername/eduplayer.git
cd eduplayer

# Install dependencies
npm install

# Run the development server
npm run dev
```

const API_BASE = "https://take-home-assessment-423502.uc.r.appspot.com/api";
const USER_ID = "phanender_yedla";

export interface CreateVideoInput {
  user_id: string;
  title: string;
  description: string;
  video_url: string;
}

//Create Video
export const createVideo = async (data: CreateVideoInput) => {
  const res = await fetch(`${API_BASE}/videos`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.detail || "Failed to create video");
  }

  return res.json();
};

export interface Video {
  id: string;
  title: string;
  description: string;
  video_url: string;
  user_id: string;
  created_at: string;
}

//fetch Videos
export const fetchVideos = async (): Promise<Video[]> => {
  const res = await fetch(`${API_BASE}/videos?user_id=${USER_ID}`);
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.detail || "Failed to fetch videos");
  }

  return data.videos;
};

export interface SingleVideo {
  id: string;
  title: string;
  description: string;
  video_url: string;
  user_id: string;
  created_at: string;
  num_comments: number;
}

//single video
export const fetchSingleVideo = async (
  video_id: string
): Promise<SingleVideo> => {
  const res = await fetch(`${API_BASE}/videos/single?video_id=${video_id}`);
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.detail || "Failed to fetch video");
  }

  return data.video;
};

export interface EditVideoInput {
  video_id: string;
  title: string;
  description: string;
}

//did not use in this challenge but added in
export const editVideo = async (data: EditVideoInput) => {
  const res = await fetch(`${API_BASE}/videos`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  const result = await res.json();

  if (!res.ok) {
    throw new Error(result.detail || "Failed to edit video");
  }

  return result;
};

const API_BASE = "https://take-home-assessment-423502.uc.r.appspot.com/api";

export interface Comment {
  id: string;
  video_id: string;
  user_id: string;
  content: string;
  created_at: string;
}

//Fetch comments for a video
export const fetchComments = async (video_id: string): Promise<Comment[]> => {
  const res = await fetch(`${API_BASE}/videos/comments?video_id=${video_id}`);
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.detail || "Failed to fetch comments");
  }

  return data.comments;
};

//Post a comment
export interface CreateCommentInput {
  video_id: string;
  user_id: string;
  content: string;
}

export const createComment = async (
  data: CreateCommentInput
): Promise<Comment> => {
  const res = await fetch(`${API_BASE}/videos/comments`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  const result = await res.json();

  if (!res.ok) {
    throw new Error(result.detail || "Failed to post comment");
  }

  return result;
};

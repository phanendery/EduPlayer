import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { fetchVideos, Video } from "../../api/videos";
import LoadingSpinner from "@/components/Loader";
import AddVideoModal from "@/components/AddVideoModal";
import { getRelativeTime } from "../../utils/utils";
import { useState } from "react";
import { Plus } from "lucide-react";
import Head from "next/head";

export default function VideosPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const {
    data: videos,
    isLoading,
    error,
  } = useQuery<Video[]>({
    queryKey: ["videos"],
    queryFn: fetchVideos,
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-300 via-blue-500 to-blue-900 p-8 text-white">
      <Head>
        <title>Home</title>
      </Head>
      <div className="flex justify-between items-center mb-6">
        <Link href="/">
          <h1 className="text-3xl font-bold text-white cursor-pointer">
            EdTech
          </h1>
        </Link>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-white text-blue-500 rounded hover:bg-gray-200 transition cursor-pointer"
        >
          <Plus size={20} /> Add Video
        </button>
      </div>

      <AddVideoModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />

      {isLoading && <LoadingSpinner />}
      {error && <p className="text-red-500">Error loading videos.</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos?.map((video) => (
          <Link
            key={video.id}
            href={`/videos/${video.id}`}
            className="border border-blue-300 rounded-xl p-4 hover:shadow-lg transition bg-white flex flex-col justify-between h-30"
          >
            <div>
              <h2 className="text-lg font-semibold text-blue-800 line-clamp-1">
                {video.title}
              </h2>
              <p className="text-sm text-gray-700 mt-1 line-clamp-1">
                {video.description}
              </p>
            </div>
            <p className="text-xs text-gray-500 mt-4">
              {getRelativeTime(video.created_at)}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}

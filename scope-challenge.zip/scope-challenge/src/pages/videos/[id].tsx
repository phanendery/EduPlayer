/* eslint-disable @typescript-eslint/no-explicit-any */
import { useRouter } from "next/router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  fetchSingleVideo,
  fetchVideos,
  SingleVideo,
  Video,
} from "../../api/videos";
import {
  fetchComments,
  createComment,
  Comment,
  CreateCommentInput,
} from "../../api/comments";
import Link from "next/link";
import LoadingSpinner from "@/components/Loader";
import Head from "next/head";

export default function VideoDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const isReady = typeof id === "string";
  const queryClient = useQueryClient();

  const {
    data: video,
    isLoading,
    error,
  } = useQuery<SingleVideo>({
    queryKey: ["video", id],
    queryFn: () => fetchSingleVideo(id as string),
    enabled: isReady,
  });

  const { data: comments, isLoading: loadingComments } = useQuery<Comment[]>({
    queryKey: ["comments", id],
    queryFn: () => fetchComments(id as string),
    enabled: isReady,
  });

  const { data: allVideos } = useQuery<Video[]>({
    queryKey: ["videos"],
    queryFn: fetchVideos,
    enabled: isReady,
  });

  const commentMutation = useMutation({
    mutationFn: (data: CreateCommentInput) => createComment(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comments", id] });
    },
  });

  if (!isReady || isLoading)
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-100 via-white to-blue-200 p-8 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  if (error || !video)
    return (
      <div className="text-center text-red-500 mt-20">Error loading video.</div>
    );

  const currentIndex = allVideos?.findIndex((v) => v.id === id);
  const prevVideo =
    currentIndex && currentIndex > 0 ? allVideos?.[currentIndex - 1] : null;
  const nextVideo =
    currentIndex !== undefined &&
    allVideos &&
    currentIndex < allVideos.length - 1
      ? allVideos[currentIndex + 1]
      : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-white to-blue-200 p-8">
      <Head>
        <title>{video.title}</title>
      </Head>
      <Link href="/videos">
        <p className="text-blue-700 hover:underline mb-4">← Back to Videos</p>
      </Link>

      <div className="max-w-3xl mx-auto bg-white p-6 rounded-xl shadow-lg space-y-4">
        <h1 className="text-3xl font-semibold text-black">{video.title}</h1>
        <p className="text-black">{video.description}</p>
        <p className="text-sm text-black">
          <strong>Uploaded by:</strong> {video.user_id}
        </p>
        <p className="text-sm text-black">
          <strong>Created at:</strong>{" "}
          {new Date(video.created_at).toLocaleString()}
        </p>
        <p className="text-sm text-black">
          <strong>Comments:</strong> {video.num_comments}
        </p>
        <video
          width="100%"
          controls
          className="rounded-lg border border-gray-300"
        >
          <source src={video.video_url} type="video/mp4" />
        </video>
        <div className="flex justify-between mt-6">
          {prevVideo ? (
            <button
              onClick={() => router.push(`/videos/${prevVideo.id}`)}
              className="text-blue-600 hover:underline cursor-pointer"
            >
              ← Previous
            </button>
          ) : (
            <div></div>
          )}

          {nextVideo && (
            <button
              onClick={() => router.push(`/videos/${nextVideo.id}`)}
              className="text-blue-600 hover:underline cursor-pointer"
            >
              Next →
            </button>
          )}
        </div>
        <h3 className="text-xl font-semibold text-black">Comments</h3>
        {loadingComments && (
          <p className="text-sm text-gray-500">Loading comments...</p>
        )}

        <ul className="space-y-4">
          {comments
            ?.slice()
            .sort(
              (a, b) =>
                new Date(a.created_at).getTime() -
                new Date(b.created_at).getTime()
            )
            .map((comment) => (
              <li key={comment.id} className="text-gray-800">
                <p>
                  <strong>{comment.user_id}</strong>: {comment.content}
                </p>
                <small className="text-gray-500">
                  {new Date(comment.created_at).toLocaleString()}
                </small>
              </li>
            ))}
        </ul>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const content = (e.target as any).comment.value;
            //hardcoded for purpose of the challenge
            const payload: CreateCommentInput = {
              video_id: id as string,
              user_id: "phanender_yedla",
              content,
            };
            commentMutation.mutate(payload);
            (e.target as any).reset();
          }}
          className="pt-4 space-y-2"
        >
          <input
            name="comment"
            placeholder="Add a comment..."
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 text-black"
          />
          <button
            type="submit"
            disabled={commentMutation.isPending}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition disabled:opacity-50"
          >
            {commentMutation.isPending ? "Posting..." : "Post"}
          </button>
        </form>
      </div>
    </div>
  );
}

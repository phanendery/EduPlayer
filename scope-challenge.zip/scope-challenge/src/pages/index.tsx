import Link from "next/link";
import Head from "next/head";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-sky-600 to-indigo-700 flex flex-col justify-center items-center text-center text-white px-4">
      <Head>
        <title>EdTech</title>
      </Head>
      <h1 className="text-5xl font-bold mb-4 drop-shadow-lg">EduPlayer</h1>
      <p className="text-lg max-w-xl drop-shadow-sm">
        Watch, share, and comment on educational videos. <br />
        Built to be simple and fast.
      </p>

      <Link href="/videos">
        <button className="mt-10 px-8 py-4 bg-white text-blue-700 rounded-xl text-lg font-semibold shadow-lg transition transform hover:scale-105 hover:bg-gray-100 animate-bounce-slow cursor-pointer">
          Get Started!
        </button>
      </Link>

      <style jsx>{`
        @keyframes bounce-slow {
          0%,
          100% {
            transform: translateX(0);
          }
          50% {
            transform: translateX(-6px);
          }
        }
        .animate-bounce-slow {
          animation: bounce-slow 2s infinite;
        }
      `}</style>
    </div>
  );
}

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createVideo, CreateVideoInput } from "../api/videos";
import { X } from "lucide-react";

interface AddVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddVideoModal({ isOpen, onClose }: AddVideoModalProps) {
  const [form, setForm] = useState<CreateVideoInput>({
    user_id: "phanender_yedla",
    title: "",
    description: "",
    video_url: "",
  });

  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: createVideo,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["videos"] });
      setForm({ ...form, title: "", description: "", video_url: "" });
      onClose();
    },
    onError: (error: Error) => alert(error.message),
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center backdrop-blur-sm bg-black/30">
      <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md relative">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Add New Video</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800 cursor-pointer"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate(form);
          }}
          className="flex flex-col gap-4"
        >
          <div>
            <label
              htmlFor="title"
              className="block text-sm font-medium text-gray-700"
            >
              Title
            </label>
            <input
              id="title"
              name="title"
              placeholder="Enter title"
              onChange={handleChange}
              value={form.title}
              className="mt-1 w-full border border-blue-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
              required
            />
          </div>

          <div>
            <label
              htmlFor="video_url"
              className="block text-sm font-medium text-gray-700"
            >
              Video URL
            </label>
            <input
              id="video_url"
              name="video_url"
              placeholder="Enter video URL"
              onChange={handleChange}
              value={form.video_url}
              className="mt-1 w-full border border-blue-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
              required
            />
          </div>

          <div>
            <label
              htmlFor="description"
              className="block text-sm font-medium text-gray-700"
            >
              Description
            </label>
            <textarea
              id="description"
              name="description"
              placeholder="Enter a short description"
              onChange={handleChange}
              value={form.description}
              className="mt-1 w-full border border-blue-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
              required
            />
          </div>

          <div className="flex justify-end gap-2 mt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition cursor-pointer"
            >
              {mutation.isPending ? "Adding..." : "Add Video"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
